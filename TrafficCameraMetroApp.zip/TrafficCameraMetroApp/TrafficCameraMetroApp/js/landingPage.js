﻿(function () {
    'use strict';

    var listRenderer;
    var headerRenderer;
    var itemRenderer;
    var pageLayout;
    var timer;

    // Custom event raised after the fragment is appended to the DOM.
    WinJS.Application.addEventListener('fragmentappended', function handler(e) {
        if (e.location === '/html/landingPage.html') {
            fragmentLoad(e.fragment, e.state);

            var searchButton = document.getElementById("search");
            searchButton.addEventListener("click", function () {
                doAddEventListenerCode();
            });

            var searchButton = document.getElementById("refresh");
            searchButton.addEventListener("click", function () {
                doCommand();
            });
            timer = setInterval(doCommand, 15000);
        }
        else {
            if (timer != null) clearInterval(timer);
        }
    });


    function doCommand() {

        var images = document.querySelectorAll(".largeTileTextTemplate .image");
        for (var i = 0; i < images.length; i++) {
                var now = new Date();
                    var ticks = now.getTime();
                    var newimagehtml = "<img class='resize' id='" + ticks + "' src='" + images[i].firstChild.src + "'>"

                    images[i].innerHTML = "";                           
                    images[i].innerHTML = newimagehtml;
        }
    }
      


    function doAddEventListenerCode() {
        var textBox = document.getElementById("searchBox"); 
        var searchValue = textBox.value.toUpperCase();
        if (searchValue[searchValue.length - 1] == 'K' && searchValue[searchValue.length - 2] == 'U')
            searchValue = textBox.value;
        else
            searchValue += ", UK";


            if (searchValue != "") {

                var requestUrl = "http://dev.virtualearth.net/REST/v1/Locations/" + searchValue + "?o=xml&key=YourBingKeyHere";
                var xmlhttp;
                xmlhttp = new XMLHttpRequest();
                xmlhttp.open("GET", requestUrl, false);
                xmlhttp.send();
                var xmlDoc = xmlhttp.responseXML;
                var lat = xmlDoc.documentElement.getElementsByTagName("Latitude")[0].childNodes[0].nodeValue;
                var lon = xmlDoc.documentElement.getElementsByTagName("Longitude")[0].childNodes[0].nodeValue;

                var items = pageData.items;


                for (var i = 0 ; i < items.length; i++) {

                    var p1 = new LatLon(lat, lon);
                    var p2 = new LatLon(items[i].lat, items[i].lon);
                    var dist = p1.distanceTo(p2);
                    
                    var unroundedFigure = dist / 1.61;

                    var roundedFigure = Math.round(unroundedFigure * 100) / 100;

                    var str = "Distance from location: " + roundedFigure.toString() + " Miles";

                    items[i].distance = str;
                }

                items = items.sort(compareDistances);
            }

            var lv = WinJS.UI.getControl(document.querySelector('.landingList'));
            updateForLayout(lv, Windows.UI.ViewManagement.ApplicationLayout.value);
    }

    function updateForLayout(lv, layout) {
        pageLayout = layout;
        if (pageLayout === Windows.UI.ViewManagement.ApplicationLayoutState.snapped) {
            WinJS.UI.setOptions(lv, {
                dataSource: pageData.groups,
                itemRenderer: listRenderer,
                groupDataSource: null,
                groupRenderer: null,
                oniteminvoked: itemInvoked
            });

            lv.layout = new WinJS.UI.ListLayout();
        } else {
            var groupDataSource = new WinJS.UI.GroupDataSource(
                    new WinJS.UI.ListDataSource(pageData.groups), function (item) {
                return {
                    key: item.data.group.key,
                    data: {
                        title: item.data.group.title,
                        click: function () {
                            WinJS.Navigation.navigate('/html/collectionPage.html', { group: item.data.group });
                        }
                    }
                };
            });

            WinJS.UI.setOptions(lv, {
                dataSource: pageData.items,
                itemRenderer: itemRenderer,
                groupDataSource: groupDataSource,
                groupRenderer: headerRenderer,
                oniteminvoked: itemInvoked
            });
            lv.layout = new WinJS.UI.GridLayout({ groupHeaderPosition: 'top' });
        }
        lv.refresh();
    }

    function layoutChanged(e) {
        var list = document.querySelector('.landingList');
        if (list) {
            var lv = WinJS.UI.getControl(list);
            updateForLayout(lv, e.layout);
        }
    }

    function fragmentLoad(elements, options) {
        try {
            var appLayout = Windows.UI.ViewManagement.ApplicationLayout.getForCurrentView();
            if (appLayout) {
                appLayout.addEventListener('layoutchanged', layoutChanged);
            }
        } catch (e) { }

        WinJS.UI.processAll(elements)
            .then(function () {
            itemRenderer = elements.querySelector('.itemTemplate');
            headerRenderer = elements.querySelector('.headerTemplate');
            //listRenderer = elements.querySelector('.listTemplate');
            var lv = WinJS.UI.getControl(elements.querySelector('.landingList'));
            updateForLayout(lv, Windows.UI.ViewManagement.ApplicationLayout.value);
        });
    }

    function itemInvoked(e) {
        if (pageLayout === Windows.UI.ViewManagement.ApplicationLayoutState.snapped) {
            var group = pageData.groups[e.detail.itemIndex];
            WinJS.Navigation.navigate('/html/collectionPage.html', { group: group });
        } else {
            var item = pageData.items[e.detail.itemIndex];
            WinJS.Navigation.navigate('/html/detailPage.html', { item: item });
        }
    }


    // The getGroups() and getItems() functions contain sample data.
    // TODO: Replace with custom data.
    function getGroups() {
        var colors = ['rgba(209, 211, 212, 1)', 'rgba(147, 149, 152, 1)', 'rgba(65, 64, 66, 1)'];
        var groups = [];

        groups.push({
            key: 'group' + 0,
            backgroundColor: colors[0 % colors.length],
            label: '',
            description: '',
            fullDescription: ''
        });

        return groups;
    }

    function compareLocations(a, b) {
        var nameA = a.title.toLowerCase();
        var nameB = b.title.toLowerCase();
        if (nameA < nameB) { return -1 }
        if (nameA > nameB) { return 1 }
        return 0;
    }

    function compareDistances(a, b) {
        var distA = a.distance;
        var distB = b.distance;
        if (distA < distB) { return -1 }
        if (distA > distB) { return 1 }
        return 0;
    }


    function getItems() {
        var colors = ['rgba(209, 211, 212, 1)', 'rgba(147, 149, 152, 1)', 'rgba(65, 64, 66, 1)'];
        var items = [];
        var xmlhttp;
        xmlhttp = new XMLHttpRequest();
        xmlhttp.open("GET", "stream.xml", false);
        xmlhttp.send();
        var xmlDoc = xmlhttp.responseXML;
        var x = xmlDoc.documentElement.getElementsByTagName("item");

        var numItems = x.length;
        for (var i = 0; i < numItems; i++) {

            var aTitle = x[i].getElementsByTagName("title")[0].childNodes[0].nodeValue;
            var src = x[i].getElementsByTagName("link")[0].childNodes[0].nodeValue;
            var latitude = x[i].getElementsByTagName("geo:Point")[0].getElementsByTagName("geo:lat")[0].childNodes[0].nodeValue;
            var longitude = x[i].getElementsByTagName("geo:Point")[0].getElementsByTagName("geo:long")[0].childNodes[0].nodeValue;

            items.push({
                group: pageData.groups[0],
                key: 'item' + i,
                title: aTitle,
                backgroundImage: "url('/images/loadingImage.png');",
                trafficImage: '<img src="' + src + '" class="resize" />',
                lat: latitude,
                lon: longitude,
                distance: ""
            });

            items.sort(compareLocations);
        }


        return items;
    }

 

    var pageData = {};
    pageData.groups = getGroups();
    pageData.items = getItems();

    WinJS.Namespace.define('landingPage', {
        fragmentLoad: fragmentLoad,
        itemInvoked: itemInvoked,
        updateList: doCommand
    });

})();

